console.log('content.js injected...')

const API_URL = 'https://melonewz.onrender.com'

const headlineElm = document.querySelector("[itemprop='headline']")
const contentElm = document.querySelector("[itemprop='articleBody']")

if(headlineElm && contentElm) initialize()

function initialize(){
    let manipulatedHeadlineHtml = null
    let manipulatedContentHtml = null
    let manipulatedUrl = null
    let originalHeadlineHtml = headlineElm.innerHTML
    let orignalContentHtml = contentElm.innerHTML
    
    let displayHelper = null;
    
    function manipulateWebpageDOM(){
        if(displayHelper != null) return;
        displayHelper = getDisplay();
        generateRhymeNews()
    }
    
    async function generateRhymeNews(){
        displayHelper.setStatus('Generating...')

        if(manipulatedHeadlineHtml && manipulatedContentHtml){
            headlineElm.innerHTML = manipulatedHeadlineHtml
            contentElm.innerHTML = manipulatedContentHtml
            displayHelper.setStatus()
            displayHelper.setLink(manipulatedUrl)
            return
        }
    
        let headline = headlineElm.textContent.trim()
        let content = Array.from(contentElm.querySelectorAll(":scope > p")).reduce((acc, cur) => {
            let text = cur.textContent.trim()
            if(acc == null) return text;
            return acc + '\n' + text
        }, null)
    
        try{
            let response = await fetch(API_URL + "/ndtv", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    headline, content, url: location.href
                })
            })
            let data = await response.json()
    
            headlineElm.textContent = data.headline
            contentElm.innerHTML = data.content
            
            displayHelper.setStatus('Generated')
            displayHelper.setLink(data.url)

            manipulatedHeadlineHtml = headlineElm.innerHTML
            manipulatedContentHtml = contentElm.innerHTML
            manipulatedUrl = data.url
        }
        catch(e){
            alert(e)
            displayHelper.setStatus('Failed')
        }
    }
    
    function getDisplay(){
        let display = document.createElement('div')
        let div = document.createElement('div')
        let status = document.createElement('div')
        let link = document.createElement('a')
    
        display.style.cssText = 'display: flex;  font-size: 13px; align-items: center;'
        div.style.cssText = 'flex: 1;'
        status.style.cssText = 'padding: 0 10px; color: #b5b5b5; font-weight: normal'
    
        div.innerHTML = `<img src='${chrome.runtime.getURL('asset/icon.png')}' height='15'>
        <b style='margin-left: 5px'>MeloNewz - NDTV</b>`
    
        link.href = ''
        link.target = '_blank'
        link.innerHTML = `<img src='${chrome.runtime.getURL('asset/link.svg')}' height='15'/>`
    
        display.append(div, status)
    
        headlineElm.insertAdjacentElement("beforebegin", display)
    
        return {
            distroy(){
                display.remove()
            },
            setStatus(statusText){
                if(statusText == '') {
                    status.remove()
                    return
                }
                status.textContent = statusText
                div.insertAdjacentElement('afterend', status)
            },
            setLink(url){
                link.href = `${API_URL}/ndtv/view?url=${url}`
                display.append(link)
            }
        }
    }
    
    function restoreDOM(){
        displayHelper.distroy()
        headlineElm.innerHTML = originalHeadlineHtml
        contentElm.innerHTML = orignalContentHtml
        displayHelper = null
    }
    
    
    
    // checking initial state
    chrome.storage.sync.get(['is_on'], function(result){
        if(result.is_on) manipulateWebpageDOM();
    })
    
    // Listen for messages from popup.js
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        log('message received - ' + request?.action)
        if (request.action == 'manipulateDOM') manipulateWebpageDOM();
        else if(request.action == 'restoreDOM') restoreDOM()
    });
    
}

// util functions
function log(text, type = 'log'){
    console[type]('MeloNewz: ' + text)
}