const main = document.getElementById("main")
const switchBtn = document.getElementById("switch-btn")
const newsList = document.getElementById('news-list')

const API_URL = 'https://melonewz.onrender.com'
const SUPPORT_HOST = "www.ndtv.com"

let supported = false;
let isSwitchOn = false;

switchBtn.onclick = () => {
    if(supported == false) return;
    main.classList.toggle("off")
    isSwitchOn = !isSwitchOn

    sendMessage({ action: isSwitchOn ? 'manipulateDOM':'restoreDOM'})

    chrome.storage.sync.set({is_on: isSwitchOn}, () => {
        if (chrome.runtime.lastError) {
            console.error('Error saving data:', chrome.runtime.lastError);
        }
    })
}

const generateSavedNews = news => {
    if(supported == false) return;

    newsList.innerHTML = null;
    news.forEach(news => {
        newsList.innerHTML += `
            <div class='news'>
                <div><h4>${news.headline}</h4><p>${news.content}</p></div>
                <a href='${API_URL}/ndtv/view?url=${news.url}' target='_blank'><img src='asset/link.svg'/></a>
            </div>
        `
    });
}

const initialize = async () => {
    // getting default state
    chrome.storage.sync.get(['is_on'], function(result) {
        console.log(result)
        isSwitchOn = result.is_on
        main.classList.toggle("off", !isSwitchOn)
    })
    
    // get saved news list
    try{
        let response = await fetch(API_URL + '/ndtv')
        let data = await response.json()
        console.log('Fetched saved news: ', data)
        generateSavedNews(data)
    }
    catch(e){
        // handle error
        console.error(e)
    }
}


document.addEventListener('DOMContentLoaded', function () {
    // checking if website is supproted
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const currentUrl = new URL(tabs[0].url);
        supported = currentUrl.host == SUPPORT_HOST;
        if(supported) {
            main.classList.remove("not-supported")
            initialize()
        }
    });
})

// send message to content.js
function sendMessage(data){
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, data);
    });
}